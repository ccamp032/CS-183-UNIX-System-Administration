#!/bin/bash


#Sources:
#

#local file location and log file location
filepath="/root/CS183-Unix-System-Adminstration/lab2/lab2_test.txt/"
savepath="/var/log/cs183/uptime.log"


# Lab2 part 3 format
thedate="$(date +'%m-%d-%y')" 
thetime="$(date +'%H:%M:%S')"
thefile="- File \"full/path/to/lab2-test\""


